-------------------------------------------------------------------
Ripped by Centrixe (previously Tiramisu6) @ The Models Resource.
https://www.models-resource.com/submitter/Centrixe/
-------------------------------------------------------------------
You can shoot me a PM for whatever.
https://www.vg-resource.com/user-31358.html
-------------------------------------------------------------------
Please credit me if you use these files.
I repeat, please credit me if you use these files!
-------------------------------------------------------------------